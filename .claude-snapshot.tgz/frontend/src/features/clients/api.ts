import { api, OfflineError } from "../../api/http";
import { cacheClients, db } from "../../offline/db";
import type { ActivityEvent, Client, Contact, ListResponse, Site } from "./types";

export type Loaded<T> = T & { fromCache?: boolean };

/** List from the server; if unreachable, fall back to the local copy. */
export async function listClients(q: string, status: string): Promise<Loaded<ListResponse<Client>>> {
  const params = new URLSearchParams({ limit: "100" });
  if (q) params.set("q", q);
  if (status) params.set("status", status);
  try {
    const res = await api<ListResponse<Client>>(`/clients?${params}`);
    await cacheClients(res.items);
    return res;
  } catch (e) {
    if (!(e instanceof OfflineError)) throw e;
    const needle = q.toLowerCase();
    let items = await db.clients.orderBy("legal_name").toArray();
    items = items.filter(
      (c) =>
        (!status || c.status === status) &&
        (!needle ||
          `${c.legal_name} ${c.trading_name ?? ""} ${c.reference} ${c.tpin ?? ""}`.toLowerCase().includes(needle)),
    );
    return { items, total: items.length, limit: items.length, offset: 0, fromCache: true };
  }
}

export async function getClient(id: string): Promise<Loaded<Client>> {
  try {
    const c = await api<Client>(`/clients/${id}`);
    await cacheClients([c]);
    return c;
  } catch (e) {
    if (!(e instanceof OfflineError)) throw e;
    const c = await db.clients.get(id);
    if (!c) throw e;
    return { ...c, fromCache: true };
  }
}

export type CreateClientInput = {
  legal_name: string;
  trading_name?: string;
  registration_no?: string;
  tpin?: string;
  sector?: string;
  billing_address?: string;
  default_currency?: string;
  credit_terms_days?: number;
  credit_limit?: string;
  notes?: string;
  contacts?: Array<Partial<Contact> & { name: string }>;
  sites?: Array<Partial<Site> & { name: string; address: string }>;
  allow_duplicate?: boolean;
  duplicate_reason?: string;
};

export const createClient = (input: CreateClientInput) => api<Client>("/clients", { method: "POST", json: input });

export const updateClient = (id: string, input: Record<string, unknown> & { version: number }) =>
  api<Client>(`/clients/${id}`, { method: "PATCH", json: input });

export const deactivateClient = (id: string, version: number, reason: string) =>
  api<Client>(`/clients/${id}/deactivate`, { method: "POST", json: { version, reason } });

export const reactivateClient = (id: string, version: number) =>
  api<Client>(`/clients/${id}/reactivate`, { method: "POST", json: { version } });

export const addContact = (id: string, c: Partial<Contact> & { name: string }) =>
  api<Contact>(`/clients/${id}/contacts`, { method: "POST", json: c });

export const addSite = (id: string, s: { name: string; address: string; contact_name?: string; contact_phone?: string }) =>
  api<Site>(`/clients/${id}/sites`, { method: "POST", json: s });

export const clientActivity = (id: string) => api<{ items: ActivityEvent[] }>(`/clients/${id}/activity`);
