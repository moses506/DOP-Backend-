export type Person = { id: string; name: string; position: string };

export type Contact = {
  id: string;
  name: string;
  position: string | null;
  email: string | null;
  phone: string | null;
  is_primary: boolean;
  active: boolean;
};

export type Site = {
  id: string;
  name: string;
  address: string;
  contact_name: string | null;
  contact_phone: string | null;
  notes: string | null;
  active: boolean;
};

export type Client = {
  id: string;
  reference: string;
  legal_name: string;
  trading_name: string | null;
  registration_no: string | null;
  tpin: string | null;
  sector: string | null;
  billing_address: string | null;
  default_currency: string;
  credit_terms_days: number;
  credit_limit: string | null;
  status: "active" | "inactive";
  notes: string | null;
  owner: Person;
  created_by: Person;
  created_at: string;
  updated_at: string;
  deactivated_at: string | null;
  deactivation_reason: string | null;
  version: number;
  contacts?: Contact[];
  sites?: Site[];
};

export type PossibleDuplicate = {
  id: string;
  reference: string;
  legal_name: string;
  status: string;
  matched_on: string[];
};

export type ActivityEvent = {
  id: number;
  occurred_at: string;
  actor_name: string;
  actor_role: string;
  action: string;
  summary: string;
  changes?: Record<string, { from: unknown; to: unknown }> | Record<string, unknown>;
  reason?: string;
};

export type ListResponse<T> = { items: T[]; total: number; limit: number; offset: number };
