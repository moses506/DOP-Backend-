import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { Link, useParams } from "react-router-dom";
import { ApiError } from "../../api/http";
import { useAuth } from "../../auth/AuthContext";
import { ErrorBanner, Field, formatDate, Input, money, StatusPill, TextArea } from "../../components/ui";
import { useOnline } from "../../offline/useOnline";
import {
  addContact,
  addSite,
  clientActivity,
  deactivateClient,
  getClient,
  reactivateClient,
  updateClient,
} from "./api";
import type { Client } from "./types";

export function ClientDetailPage() {
  const { id = "" } = useParams();
  const { can } = useAuth();
  const online = useOnline();
  const { data: c, error, isLoading } = useQuery({ queryKey: ["client", id], queryFn: () => getClient(id) });

  if (isLoading) return <p className="muted">Loading…</p>;
  if (!c) return <ErrorBanner error={error ?? new Error("Not found")} />;

  const editable = !c.fromCache && online;

  return (
    <section>
      <div className="page-head">
        <div>
          <Link to="/clients" className="back">
            ← Clients
          </Link>
          <div className="title-row">
            <h1>{c.legal_name}</h1>
            <StatusPill status={c.status} />
          </div>
          <p className="muted">
            <span className="mono">{c.reference}</span>
            {c.trading_name && <> · trading as {c.trading_name}</>}
          </p>
        </div>
      </div>

      {c.fromCache && <div className="banner banner-warn">Offline — showing the copy saved on this device.</div>}
      {c.status === "inactive" && (
        <div className="banner banner-warn">
          Deactivated {formatDate(c.deactivated_at)}: {c.deactivation_reason}. No new documents can be issued.
        </div>
      )}

      <div className="detail-grid">
        <div className="stack">
          <Details client={c} editable={editable && can("clients:update")} />
          <Contacts client={c} editable={editable && can("clients:update") && c.status === "active"} />
          <Sites client={c} editable={editable && can("clients:update") && c.status === "active"} />
        </div>
        <div className="stack">
          <Ownership client={c} />
          {editable && can("clients:deactivate") && <StatusControl client={c} />}
          {!c.fromCache && <Activity id={c.id} />}
        </div>
      </div>
    </section>
  );
}

function useRefresh(id: string) {
  const qc = useQueryClient();
  return (c?: Client) => {
    if (c) qc.setQueryData(["client", id], c);
    qc.invalidateQueries({ queryKey: ["client", id] });
    qc.invalidateQueries({ queryKey: ["activity", id] });
    qc.invalidateQueries({ queryKey: ["clients"] });
  };
}

function staleMessage(e: unknown) {
  return e instanceof ApiError && e.code === "stale_version"
    ? "Someone else changed this client. The latest version has been loaded — review it and try again."
    : null;
}

function Details({ client: c, editable }: { client: Client; editable: boolean }) {
  const [editing, setEditing] = useState(false);
  const [f, setF] = useState(() => toForm(c));
  const refresh = useRefresh(c.id);
  const m = useMutation({
    mutationFn: () =>
      updateClient(c.id, {
        version: c.version,
        legal_name: f.legal_name,
        trading_name: f.trading_name,
        registration_no: f.registration_no,
        tpin: f.tpin,
        sector: f.sector,
        billing_address: f.billing_address,
        default_currency: f.default_currency,
        credit_terms_days: Number(f.credit_terms_days),
        credit_limit: f.credit_limit,
        notes: f.notes,
      }),
    onSuccess: (updated) => {
      refresh(updated);
      setEditing(false);
    },
    onError: (e) => {
      if (staleMessage(e)) refresh();
    },
  });
  const fe = m.error instanceof ApiError ? m.error.fields : {};
  const set = (k: keyof ReturnType<typeof toForm>) => (e: { target: { value: string } }) =>
    setF({ ...f, [k]: e.target.value });

  if (!editing) {
    return (
      <div className="card">
        <div className="card-head">
          <h2>Details</h2>
          {editable && (
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setF(toForm(c));
                m.reset();
                setEditing(true);
              }}
            >
              Edit
            </button>
          )}
        </div>
        <dl className="dl">
          <dt>PACRA reg. no.</dt>
          <dd>{c.registration_no ?? "—"}</dd>
          <dt>TPIN</dt>
          <dd>{c.tpin ?? "—"}</dd>
          <dt>Sector</dt>
          <dd>{c.sector ?? "—"}</dd>
          <dt>Billing address</dt>
          <dd className="pre">{c.billing_address ?? "—"}</dd>
          <dt>Currency</dt>
          <dd>{c.default_currency}</dd>
          <dt>Credit terms</dt>
          <dd>{c.credit_terms_days} days</dd>
          <dt>Credit limit</dt>
          <dd>{money(c.credit_limit, c.default_currency)}</dd>
          <dt>Notes</dt>
          <dd className="pre">{c.notes ?? "—"}</dd>
        </dl>
      </div>
    );
  }

  return (
    <form
      className="card form"
      onSubmit={(e: FormEvent) => {
        e.preventDefault();
        m.mutate();
      }}
    >
      <h2>Edit details</h2>
      {staleMessage(m.error) ? (
        <div className="banner banner-warn">{staleMessage(m.error)}</div>
      ) : (
        m.error && Object.keys(fe).length === 0 && <ErrorBanner error={m.error} />
      )}
      <div className="grid-2">
        <Field label="Legal name" error={fe.legal_name}>
          <Input value={f.legal_name} onChange={set("legal_name")} />
        </Field>
        <Field label="Trading name">
          <Input value={f.trading_name} onChange={set("trading_name")} />
        </Field>
        <Field label="PACRA reg. no." error={fe.registration_no}>
          <Input value={f.registration_no} onChange={set("registration_no")} />
        </Field>
        <Field label="TPIN" error={fe.tpin}>
          <Input value={f.tpin} onChange={set("tpin")} />
        </Field>
        <Field label="Sector">
          <Input value={f.sector} onChange={set("sector")} />
        </Field>
        <Field label="Currency" error={fe.default_currency}>
          <Input value={f.default_currency} onChange={set("default_currency")} maxLength={3} />
        </Field>
        <Field label="Credit terms (days)" error={fe.credit_terms_days}>
          <Input type="number" value={f.credit_terms_days} onChange={set("credit_terms_days")} />
        </Field>
        <Field label="Credit limit" error={fe.credit_limit} hint="Leave empty for no limit">
          <Input value={f.credit_limit} onChange={set("credit_limit")} />
        </Field>
      </div>
      <Field label="Billing address">
        <TextArea value={f.billing_address} onChange={set("billing_address")} rows={2} />
      </Field>
      <Field label="Notes">
        <TextArea value={f.notes} onChange={set("notes")} />
      </Field>
      <div className="form-actions">
        <button type="button" className="btn btn-ghost" onClick={() => setEditing(false)}>
          Cancel
        </button>
        <button className="btn btn-primary" disabled={m.isPending}>
          Save
        </button>
      </div>
    </form>
  );
}

function toForm(c: Client) {
  return {
    legal_name: c.legal_name,
    trading_name: c.trading_name ?? "",
    registration_no: c.registration_no ?? "",
    tpin: c.tpin ?? "",
    sector: c.sector ?? "",
    billing_address: c.billing_address ?? "",
    default_currency: c.default_currency,
    credit_terms_days: String(c.credit_terms_days),
    credit_limit: c.credit_limit ?? "",
    notes: c.notes ?? "",
  };
}

function Ownership({ client: c }: { client: Client }) {
  return (
    <div className="card">
      <h2>Responsibility</h2>
      <dl className="dl">
        <dt>Responsible</dt>
        <dd>
          {c.owner.name}
          <div className="muted small">{c.owner.position}</div>
        </dd>
        <dt>Registered by</dt>
        <dd>
          {c.created_by.name}
          <div className="muted small">{formatDate(c.created_at, true)}</div>
        </dd>
        <dt>Last activity</dt>
        <dd>{formatDate(c.updated_at, true)}</dd>
      </dl>
    </div>
  );
}

function Contacts({ client: c, editable }: { client: Client; editable: boolean }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", position: "", email: "", phone: "", is_primary: false });
  const refresh = useRefresh(c.id);
  const m = useMutation({
    mutationFn: () => addContact(c.id, f),
    onSuccess: () => {
      refresh();
      setOpen(false);
      setF({ name: "", position: "", email: "", phone: "", is_primary: false });
    },
  });
  const fe = m.error instanceof ApiError ? m.error.fields : {};
  const contacts = (c.contacts ?? []).filter((x) => x.active);

  return (
    <div className="card">
      <div className="card-head">
        <h2>Contacts</h2>
        {editable && !open && (
          <button className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>
            Add contact
          </button>
        )}
      </div>
      {contacts.length === 0 && <p className="muted small">No contacts yet.</p>}
      <ul className="list">
        {contacts.map((x) => (
          <li key={x.id}>
            <strong>{x.name}</strong> {x.is_primary && <span className="pill pill-primary">primary</span>}
            <div className="muted small">
              {[x.position, x.email, x.phone].filter(Boolean).join(" · ") || "No details"}
            </div>
          </li>
        ))}
      </ul>
      {open && (
        <form
          className="form inset"
          onSubmit={(e) => {
            e.preventDefault();
            m.mutate();
          }}
        >
          <div className="grid-2">
            <Field label="Name" error={fe.name}>
              <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
            </Field>
            <Field label="Position">
              <Input value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} />
            </Field>
            <Field label="Email" error={fe.email}>
              <Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
            </Field>
            <Field label="Phone">
              <Input type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
            </Field>
          </div>
          <label className="check">
            <input type="checkbox" checked={f.is_primary} onChange={(e) => setF({ ...f, is_primary: e.target.checked })} />
            Primary contact
          </label>
          {m.error && Object.keys(fe).length === 0 && <ErrorBanner error={m.error} />}
          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" disabled={m.isPending}>
              Add
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

function Sites({ client: c, editable }: { client: Client; editable: boolean }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", address: "", contact_name: "", contact_phone: "" });
  const refresh = useRefresh(c.id);
  const m = useMutation({
    mutationFn: () => addSite(c.id, f),
    onSuccess: () => {
      refresh();
      setOpen(false);
      setF({ name: "", address: "", contact_name: "", contact_phone: "" });
    },
  });
  const fe = m.error instanceof ApiError ? m.error.fields : {};
  const sites = (c.sites ?? []).filter((x) => x.active);

  return (
    <div className="card">
      <div className="card-head">
        <h2>Delivery sites</h2>
        {editable && !open && (
          <button className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>
            Add site
          </button>
        )}
      </div>
      {sites.length === 0 && <p className="muted small">No delivery sites yet.</p>}
      <ul className="list">
        {sites.map((s) => (
          <li key={s.id}>
            <strong>{s.name}</strong>
            <div className="muted small">
              {[s.address, s.contact_name, s.contact_phone].filter(Boolean).join(" · ")}
            </div>
          </li>
        ))}
      </ul>
      {open && (
        <form
          className="form inset"
          onSubmit={(e) => {
            e.preventDefault();
            m.mutate();
          }}
        >
          <div className="grid-2">
            <Field label="Site name" error={fe.name}>
              <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
            </Field>
            <Field label="Address" error={fe.address}>
              <Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
            </Field>
            <Field label="Site contact">
              <Input value={f.contact_name} onChange={(e) => setF({ ...f, contact_name: e.target.value })} />
            </Field>
            <Field label="Site phone">
              <Input type="tel" value={f.contact_phone} onChange={(e) => setF({ ...f, contact_phone: e.target.value })} />
            </Field>
          </div>
          {m.error && Object.keys(fe).length === 0 && <ErrorBanner error={m.error} />}
          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" disabled={m.isPending}>
              Add
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

function StatusControl({ client: c }: { client: Client }) {
  const [reason, setReason] = useState("");
  const refresh = useRefresh(c.id);
  const m = useMutation({
    mutationFn: () => (c.status === "active" ? deactivateClient(c.id, c.version, reason) : reactivateClient(c.id, c.version)),
    onSuccess: (updated) => {
      refresh(updated);
      setReason("");
    },
    onError: (e) => {
      if (staleMessage(e)) refresh();
    },
  });
  const fe = m.error instanceof ApiError ? m.error.fields : {};

  return (
    <div className="card">
      <h2>Status</h2>
      {staleMessage(m.error) && <div className="banner banner-warn">{staleMessage(m.error)}</div>}
      {c.status === "active" ? (
        <>
          <p className="muted small">Clients are never deleted. Deactivating keeps all history and blocks new documents.</p>
          <Field label="Reason" error={fe.reason}>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
          <button className="btn btn-danger" disabled={!reason.trim() || m.isPending} onClick={() => m.mutate()}>
            Deactivate client
          </button>
        </>
      ) : (
        <button className="btn btn-primary" disabled={m.isPending} onClick={() => m.mutate()}>
          Reactivate client
        </button>
      )}
    </div>
  );
}

function Activity({ id }: { id: string }) {
  const { data } = useQuery({ queryKey: ["activity", id], queryFn: () => clientActivity(id) });
  return (
    <div className="card">
      <h2>Activity</h2>
      <ol className="timeline">
        {data?.items.map((ev) => (
          <li key={ev.id}>
            <div>{ev.summary}</div>
            {ev.reason && <div className="small">Reason: {ev.reason}</div>}
            <div className="muted small">
              {ev.actor_name} · {formatDate(ev.occurred_at, true)}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
