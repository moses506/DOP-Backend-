import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ApiError } from "../../api/http";
import { useAuth } from "../../auth/AuthContext";
import { ErrorBanner, Field, Input, TextArea } from "../../components/ui";
import { createClient, type CreateClientInput } from "./api";
import type { PossibleDuplicate } from "./types";

const empty = {
  legal_name: "",
  trading_name: "",
  registration_no: "",
  tpin: "",
  sector: "",
  billing_address: "",
  default_currency: "ZMW",
  credit_terms_days: "30",
  credit_limit: "",
  notes: "",
  contact_name: "",
  contact_position: "",
  contact_email: "",
  contact_phone: "",
  site_name: "",
  site_address: "",
};

export function ClientNewPage() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [f, setF] = useState(empty);
  const [dups, setDups] = useState<PossibleDuplicate[] | null>(null);
  const [overrideReason, setOverrideReason] = useState("");

  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  const mutation = useMutation({
    mutationFn: (input: CreateClientInput) => createClient(input),
    onSuccess: (c) => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      navigate(`/clients/${c.id}`);
    },
    onError: (e) => {
      if (e instanceof ApiError && e.code === "possible_duplicate") {
        setDups((e.details as { matches: PossibleDuplicate[] }).matches);
      }
    },
  });

  const fieldErrors = mutation.error instanceof ApiError ? mutation.error.fields : {};
  const err = (k: string) => fieldErrors[k];

  function build(allowDuplicate: boolean): CreateClientInput {
    const opt = (s: string) => (s.trim() ? s.trim() : undefined);
    return {
      legal_name: f.legal_name,
      trading_name: opt(f.trading_name),
      registration_no: opt(f.registration_no),
      tpin: opt(f.tpin),
      sector: opt(f.sector),
      billing_address: opt(f.billing_address),
      default_currency: f.default_currency,
      credit_terms_days: Number(f.credit_terms_days),
      credit_limit: opt(f.credit_limit),
      notes: opt(f.notes),
      contacts: f.contact_name.trim()
        ? [
            {
              name: f.contact_name,
              position: opt(f.contact_position),
              email: opt(f.contact_email),
              phone: opt(f.contact_phone),
              is_primary: true,
            },
          ]
        : [],
      sites: f.site_name.trim() ? [{ name: f.site_name, address: f.site_address }] : [],
      ...(allowDuplicate ? { allow_duplicate: true, duplicate_reason: overrideReason } : {}),
    };
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    setDups(null);
    mutation.mutate(build(false));
  }

  const showBanner = mutation.error && !(mutation.error instanceof ApiError && mutation.error.code === "possible_duplicate");

  return (
    <section className="narrow">
      <div className="page-head">
        <div>
          <Link to="/clients" className="back">
            ← Clients
          </Link>
          <h1>Register client</h1>
          <p className="muted">The reference number is allocated by the system when you save.</p>
        </div>
      </div>

      {showBanner && <ErrorBanner error={mutation.error} />}

      {dups && (
        <div className="banner banner-warn">
          <strong>This client may already be registered.</strong>
          <ul className="dup-list">
            {dups.map((d) => (
              <li key={d.id}>
                <Link to={`/clients/${d.id}`}>
                  {d.reference} – {d.legal_name}
                </Link>{" "}
                <span className="muted small">
                  ({d.status}; matched on {d.matched_on.join(", ").replace("_", " ")})
                </span>
              </li>
            ))}
          </ul>
          {can("clients:override_duplicate") ? (
            <div className="override">
              <Field label="Reason for registering anyway" error={err("duplicate_reason")}>
                <Input value={overrideReason} onChange={(e) => setOverrideReason(e.target.value)} />
              </Field>
              <button
                type="button"
                className="btn btn-warn"
                disabled={!overrideReason.trim() || mutation.isPending}
                onClick={() => mutation.mutate(build(true))}
              >
                Register as a separate client
              </button>
            </div>
          ) : (
            <p className="small">Use the existing record, or ask a sales manager to approve a separate registration.</p>
          )}
        </div>
      )}

      <form onSubmit={submit} className="card form">
        <h2>Company</h2>
        <div className="grid-2">
          <Field label="Legal name *" error={err("legal_name")}>
            <Input value={f.legal_name} onChange={set("legal_name")} required />
          </Field>
          <Field label="Trading name" error={err("trading_name")}>
            <Input value={f.trading_name} onChange={set("trading_name")} />
          </Field>
          <Field label="PACRA registration no." error={err("registration_no")}>
            <Input value={f.registration_no} onChange={set("registration_no")} />
          </Field>
          <Field label="TPIN" error={err("tpin")} hint="10 digits">
            <Input value={f.tpin} onChange={set("tpin")} inputMode="numeric" />
          </Field>
          <Field label="Sector" error={err("sector")}>
            <Input value={f.sector} onChange={set("sector")} list="sectors" />
            <datalist id="sectors">
              {["Mining", "Government", "Banking & finance", "Telecoms", "Energy", "Health", "Education", "Retail", "NGO"].map(
                (s) => (
                  <option key={s} value={s} />
                ),
              )}
            </datalist>
          </Field>
          <Field label="Billing address" error={err("billing_address")}>
            <TextArea value={f.billing_address} onChange={set("billing_address")} rows={2} />
          </Field>
        </div>

        <h2>Commercial terms</h2>
        <div className="grid-3">
          <Field label="Currency" error={err("default_currency")}>
            <select className="input select" value={f.default_currency} onChange={set("default_currency")}>
              <option>ZMW</option>
              <option>USD</option>
              <option>ZAR</option>
              <option>EUR</option>
            </select>
          </Field>
          <Field label="Credit terms (days)" error={err("credit_terms_days")}>
            <Input type="number" min={0} max={365} value={f.credit_terms_days} onChange={set("credit_terms_days")} />
          </Field>
          <Field label="Credit limit" error={err("credit_limit")} hint="Optional">
            <Input value={f.credit_limit} onChange={set("credit_limit")} inputMode="decimal" />
          </Field>
        </div>

        <h2>Primary contact</h2>
        <div className="grid-2">
          <Field label="Name" error={err("contacts.0.name")}>
            <Input value={f.contact_name} onChange={set("contact_name")} />
          </Field>
          <Field label="Position">
            <Input value={f.contact_position} onChange={set("contact_position")} />
          </Field>
          <Field label="Email" error={err("contacts.0.email")}>
            <Input type="email" value={f.contact_email} onChange={set("contact_email")} />
          </Field>
          <Field label="Phone">
            <Input type="tel" value={f.contact_phone} onChange={set("contact_phone")} />
          </Field>
        </div>

        <h2>Delivery site</h2>
        <div className="grid-2">
          <Field label="Site name" error={err("sites.0.name")} hint="e.g. Kansanshi Mine – Main stores">
            <Input value={f.site_name} onChange={set("site_name")} />
          </Field>
          <Field label="Site address" error={err("sites.0.address")}>
            <Input value={f.site_address} onChange={set("site_address")} />
          </Field>
        </div>

        <Field label="Notes">
          <TextArea value={f.notes} onChange={set("notes")} />
        </Field>

        <div className="form-actions">
          <Link to="/clients" className="btn btn-ghost">
            Cancel
          </Link>
          <button className="btn btn-primary" disabled={mutation.isPending}>
            {mutation.isPending ? "Saving…" : "Register client"}
          </button>
        </div>
      </form>
    </section>
  );
}
