import { useQuery } from "@tanstack/react-query";
import { useDeferredValue, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../auth/AuthContext";
import { ErrorBanner, formatDate, Input, StatusPill } from "../../components/ui";
import { listClients } from "./api";

export function ClientsPage() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("active");
  const query = useDeferredValue(q);

  const { data, error, isLoading } = useQuery({
    queryKey: ["clients", query, status],
    queryFn: () => listClients(query, status),
  });

  return (
    <section>
      <div className="page-head">
        <div>
          <h1>Clients</h1>
          <p className="muted">Every client is registered once here before any quotation, order or invoice.</p>
        </div>
        {can("clients:create") && (
          <Link to="/clients/new" className="btn btn-primary">
            Register client
          </Link>
        )}
      </div>

      <div className="toolbar">
        <Input
          type="search"
          placeholder="Search name, reference or TPIN"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Search clients"
        />
        <select className="input select" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="">All</option>
        </select>
      </div>

      {data?.fromCache && (
        <div className="banner banner-warn">Offline — showing clients saved on this device.</div>
      )}
      <ErrorBanner error={error} />

      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Reference</th>
              <th>Client</th>
              <th className="hide-sm">Sector</th>
              <th className="hide-sm">Responsible</th>
              <th className="hide-sm">Terms</th>
              <th>Status</th>
              <th className="hide-sm">Updated</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={7} className="muted center">
                  Loading…
                </td>
              </tr>
            )}
            {data?.items.length === 0 && (
              <tr>
                <td colSpan={7} className="muted center">
                  No clients match.
                </td>
              </tr>
            )}
            {data?.items.map((c) => (
              <tr key={c.id} className="row-link" onClick={() => navigate(`/clients/${c.id}`)}>
                <td className="mono">
                  <Link to={`/clients/${c.id}`} onClick={(e) => e.stopPropagation()}>
                    {c.reference}
                  </Link>
                </td>
                <td>
                  <strong>{c.legal_name}</strong>
                  {c.trading_name && <div className="muted small">t/a {c.trading_name}</div>}
                </td>
                <td className="hide-sm">{c.sector ?? "—"}</td>
                <td className="hide-sm">
                  {c.owner.name}
                  <div className="muted small">{c.owner.position}</div>
                </td>
                <td className="hide-sm">{c.credit_terms_days} days</td>
                <td>
                  <StatusPill status={c.status} />
                </td>
                <td className="hide-sm">{formatDate(c.updated_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data && !data.fromCache && data.total > data.items.length && (
        <p className="muted small">
          Showing {data.items.length} of {data.total}. Refine the search to narrow results.
        </p>
      )}
    </section>
  );
}
