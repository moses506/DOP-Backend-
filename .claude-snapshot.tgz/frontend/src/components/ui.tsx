import type { InputHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { ApiError, OfflineError } from "../api/http";

export function Field({
  label,
  error,
  hint,
  children,
}: {
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className={`field${error ? " has-error" : ""}`}>
      <span className="field-label">{label}</span>
      {children}
      {error ? <span className="field-error">{error}</span> : hint ? <span className="field-hint">{hint}</span> : null}
    </label>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input className="input" {...props} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="input" rows={3} {...props} />;
}

export function ErrorBanner({ error }: { error: unknown }) {
  if (!error) return null;
  let msg = "Something went wrong.";
  if (error instanceof OfflineError) msg = "You are offline. This action needs a connection.";
  else if (error instanceof ApiError) msg = error.message;
  return (
    <div className="banner banner-error" role="alert">
      {msg}
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  return <span className={`pill pill-${status}`}>{status}</span>;
}

export function formatDate(iso: string | null | undefined, withTime = false) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("en-ZM", {
    day: "numeric",
    month: "short",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  });
}

export function money(amount: string | null, currency: string) {
  if (!amount) return "—";
  return `${currency} ${Number(amount).toLocaleString("en-ZM", { minimumFractionDigits: 2 })}`;
}
