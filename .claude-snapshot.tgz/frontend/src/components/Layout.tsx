import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { useOnline } from "../offline/useOnline";

// Modules from the implementation brief. Each becomes live as it is built.
const NAV: Array<{ to: string; label: string; live: boolean }> = [
  { to: "/clients", label: "Clients", live: true },
  { to: "/deals", label: "Deals", live: false },
  { to: "/quotations", label: "Quotations", live: false },
  { to: "/orders", label: "Customer orders", live: false },
  { to: "/purchase-orders", label: "Supplier POs", live: false },
  { to: "/deliveries", label: "Delivery notes", live: false },
  { to: "/jobs", label: "Job cards", live: false },
  { to: "/invoices", label: "Invoices", live: false },
  { to: "/tenders", label: "Tenders", live: false },
  { to: "/dashboard", label: "Dashboard", live: false },
];

export function Layout() {
  const { session, logout } = useAuth();
  const online = useOnline();

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <img src="/icon.svg" alt="" width={28} height={28} />
          <div>
            <strong>DOS Workflow</strong>
            <span>Digital Office Solutions</span>
          </div>
        </div>
        <nav>
          {NAV.map((n) =>
            n.live ? (
              <NavLink key={n.to} to={n.to} className="nav-link">
                {n.label}
              </NavLink>
            ) : (
              <span key={n.to} className="nav-link nav-soon" title="Planned module">
                {n.label}
              </span>
            ),
          )}
        </nav>
      </aside>

      <div className="main">
        <header className="topbar">
          <span className={`net ${online ? "net-on" : "net-off"}`}>{online ? "Online" : "Offline"}</span>
          <div className="who">
            <strong>{session?.user.full_name}</strong>
            <span>{session?.user.position}</span>
          </div>
          <button className="btn btn-ghost" onClick={logout}>
            Sign out
          </button>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
