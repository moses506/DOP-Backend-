import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, sessionStorageKey, setUnauthorizedHandler } from "../api/http";
import { clearOfflineData } from "../offline/db";

export type User = {
  id: string;
  email: string;
  full_name: string;
  position: string;
  department: string;
  role: string;
};

type Session = { token: string; expires_at: string; user: User; permissions: string[] };

type AuthValue = {
  session: Session | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  can: (perm: string) => boolean;
};

const AuthContext = createContext<AuthValue | null>(null);

function load(): Session | null {
  try {
    const raw = localStorage.getItem(sessionStorageKey);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    // The session survives going offline until the token expires; that is the
    // "offline validity period" from the brief. Shorten ACCESS_TOKEN_TTL to tighten it.
    return new Date(s.expires_at) > new Date() ? s : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(load);

  const logout = useCallback(() => {
    localStorage.removeItem(sessionStorageKey);
    void clearOfflineData(); // do not leave client data on a shared device
    setSession(null);
  }, []);

  useEffect(() => setUnauthorizedHandler(logout), [logout]);

  const login = useCallback(async (email: string, password: string) => {
    const s = await api<Session>("/auth/login", { method: "POST", json: { email, password } });
    localStorage.setItem(sessionStorageKey, JSON.stringify(s));
    setSession(s);
  }, []);

  const value = useMemo<AuthValue>(
    () => ({
      session,
      login,
      logout,
      can: (perm) => session?.permissions.includes(perm) ?? false,
    }),
    [session, login, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const v = useContext(AuthContext);
  if (!v) throw new Error("useAuth outside AuthProvider");
  return v;
}
