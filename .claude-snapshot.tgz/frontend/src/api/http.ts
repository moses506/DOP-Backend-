// Thin fetch wrapper. Every API error has the same shape:
// { error: { code, message, details } } — see backend internal/platform/httpx.

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
  /** Field-level validation messages, if any. */
  get fields(): Record<string, string> {
    return this.code === "validation_failed" && this.details && typeof this.details === "object"
      ? (this.details as Record<string, string>)
      : {};
  }
}

/** Thrown when the server could not be reached at all (offline, DNS, timeout). */
export class OfflineError extends Error {
  constructor() {
    super("You appear to be offline.");
  }
}

const TOKEN_KEY = "dos.session";
let onUnauthorized: () => void = () => {};

export function setUnauthorizedHandler(fn: () => void) {
  onUnauthorized = fn;
}

function token(): string | null {
  try {
    const raw = localStorage.getItem(TOKEN_KEY);
    return raw ? (JSON.parse(raw).token as string) : null;
  } catch {
    return null;
  }
}

export async function api<T>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const t = token();
  if (t) headers.set("Authorization", `Bearer ${t}`);
  let body = init.body;
  if (init.json !== undefined) {
    headers.set("Content-Type", "application/json");
    body = JSON.stringify(init.json);
  }

  let res: Response;
  try {
    res = await fetch(`/api${path}`, { ...init, headers, body });
  } catch {
    throw new OfflineError();
  }

  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const e = data?.error ?? {};
    if (res.status === 401 && path !== "/auth/login") onUnauthorized();
    throw new ApiError(res.status, e.code ?? "error", e.message ?? res.statusText, e.details);
  }
  return data as T;
}

export const sessionStorageKey = TOKEN_KEY;
