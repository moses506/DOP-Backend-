import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import { Layout } from "./components/Layout";
import { ClientDetailPage } from "./features/clients/ClientDetailPage";
import { ClientNewPage } from "./features/clients/ClientNewPage";
import { ClientsPage } from "./features/clients/ClientsPage";
import { LoginPage } from "./pages/Login";

function RequireSession({ children }: { children: React.ReactNode }) {
  const { session } = useAuth();
  return session ? <>{children}</> : <Navigate to="/login" replace />;
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        element={
          <RequireSession>
            <Layout />
          </RequireSession>
        }
      >
        <Route path="/clients" element={<ClientsPage />} />
        <Route path="/clients/new" element={<ClientNewPage />} />
        <Route path="/clients/:id" element={<ClientDetailPage />} />
        <Route path="*" element={<Navigate to="/clients" replace />} />
      </Route>
    </Routes>
  );
}
