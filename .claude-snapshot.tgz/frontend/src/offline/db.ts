import Dexie, { type EntityTable } from "dexie";
import type { Client } from "../features/clients/types";

// Local IndexedDB store for offline use.
//
// - clients: read cache of records the user has loaded, so client details are
//   available at mine sites with no signal.
// - outbox: reserved for the field modules (delivery notes, job cards). Each
//   entry is a record created offline with a temporary local id; the sync
//   endpoint assigns the final DOS number on upload. See README "Offline sync".
export type OutboxItem = {
  localId: string; // crypto.randomUUID(), also sent as the idempotency key
  kind: "delivery_note" | "job_card";
  payload: unknown;
  status: "pending" | "syncing" | "synced" | "failed";
  error?: string;
  createdAt: string;
  attempts: number;
};

export type Meta = { key: string; value: string };

export const db = new Dexie("dos-bpas") as Dexie & {
  clients: EntityTable<Client, "id">;
  outbox: EntityTable<OutboxItem, "localId">;
  meta: EntityTable<Meta, "key">;
};

db.version(1).stores({
  clients: "id, reference, legal_name, status, updated_at",
  outbox: "localId, kind, status, createdAt",
  meta: "key",
});

export async function cacheClients(items: Client[]) {
  // Keep detail fields (contacts, sites) if a list response lacks them.
  await db.transaction("rw", db.clients, async () => {
    for (const c of items) {
      const prev = await db.clients.get(c.id);
      await db.clients.put({ ...prev, ...c, contacts: c.contacts ?? prev?.contacts, sites: c.sites ?? prev?.sites });
    }
  });
  await db.meta.put({ key: "clients.syncedAt", value: new Date().toISOString() });
}

export async function clearOfflineData() {
  await Promise.all([db.clients.clear(), db.meta.clear()]);
}
