import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

// The app shell is cached by the service worker so it opens with no network.
// Business data is cached separately in IndexedDB (src/offline/db.ts), never by
// the service worker, so stale API responses are never served silently.
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icon.svg"],
      manifest: {
        name: "DOS Business Process Automation",
        short_name: "DOS Workflow",
        description: "Digital Office Solutions everyday workflow system",
        theme_color: "#0f2a4a",
        background_color: "#f5f7fa",
        display: "standalone",
        start_url: "/",
        icons: [{ src: "icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }],
      },
      workbox: {
        navigateFallback: "/index.html",
        navigateFallbackDenylist: [/^\/api\//, /^\/healthz/],
        globPatterns: ["**/*.{js,css,html,svg,woff2}"],
      },
    }),
  ],
  server: {
    port: 5173,
    proxy: { "/api": "http://localhost:8080", "/healthz": "http://localhost:8080" },
  },
});
