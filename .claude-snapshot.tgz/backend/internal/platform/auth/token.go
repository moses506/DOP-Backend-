package auth

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
)

type claims struct {
	Name     string `json:"name"`
	Position string `json:"pos"`
	Role     Role   `json:"role"`
	jwt.RegisteredClaims
}

type Tokens struct {
	secret []byte
	ttl    time.Duration
}

func NewTokens(secret []byte, ttl time.Duration) *Tokens { return &Tokens{secret: secret, ttl: ttl} }

func (t *Tokens) Issue(p Principal, now time.Time) (string, time.Time, error) {
	exp := now.Add(t.ttl)
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, claims{
		Name: p.Name, Position: p.Position, Role: p.Role,
		RegisteredClaims: jwt.RegisteredClaims{
			Subject:   p.UserID.String(),
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(exp),
			Issuer:    "dos-bpas",
		},
	})
	s, err := tok.SignedString(t.secret)
	return s, exp, err
}

func (t *Tokens) Parse(raw string) (Principal, error) {
	var c claims
	_, err := jwt.ParseWithClaims(raw, &c, func(*jwt.Token) (any, error) { return t.secret, nil },
		jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Alg()}),
		jwt.WithIssuer("dos-bpas"),
		jwt.WithExpirationRequired(),
	)
	if err != nil {
		return Principal{}, err
	}
	id, err := uuid.Parse(c.Subject)
	if err != nil {
		return Principal{}, errors.New("bad subject")
	}
	if !c.Role.Valid() {
		return Principal{}, errors.New("bad role")
	}
	return Principal{UserID: id, Name: c.Name, Position: c.Position, Role: c.Role}, nil
}
