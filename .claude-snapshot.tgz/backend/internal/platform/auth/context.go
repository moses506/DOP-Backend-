package auth

import (
	"context"

	"github.com/google/uuid"
)

// Principal is the authenticated user making a request. Services read it from
// the request context to record ownership and audit entries.
type Principal struct {
	UserID   uuid.UUID `json:"id"`
	Name     string    `json:"name"`
	Position string    `json:"position"`
	Role     Role      `json:"role"`
}

func (p Principal) Can(perm string) bool { return p.Role.Can(perm) }

type ctxKey struct{}

func WithPrincipal(ctx context.Context, p Principal) context.Context {
	return context.WithValue(ctx, ctxKey{}, p)
}

func FromContext(ctx context.Context) (Principal, bool) {
	p, ok := ctx.Value(ctxKey{}).(Principal)
	return p, ok
}
