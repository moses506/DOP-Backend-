package auth

import "strings"

// Role names match the access roles in the implementation brief (section 2).
type Role string

const (
	RoleCEO            Role = "ceo"
	RoleSalesManager   Role = "sales_manager"
	RoleSalesExecutive Role = "sales_executive"
	RoleOperations     Role = "operations"
	RoleTechnical      Role = "technical"
	RoleFinance        Role = "finance"
	RoleAdmin          Role = "admin"
)

var Roles = []Role{RoleCEO, RoleSalesManager, RoleSalesExecutive, RoleOperations, RoleTechnical, RoleFinance, RoleAdmin}

func (r Role) Valid() bool {
	for _, x := range Roles {
		if r == x {
			return true
		}
	}
	return false
}

// rolePermissions is the single place to review who can do what.
// Permissions are "resource:action". Patterns may use "*" for either part.
// Each module declares its own permission constants; add them here when a
// module is introduced.
var rolePermissions = map[Role][]string{
	RoleAdmin: {"*:*"},
	RoleCEO: {
		"*:read",
		"clients:*",
		"audit:read",
	},
	RoleSalesManager: {
		"clients:read", "clients:create", "clients:update",
		"clients:deactivate", "clients:override_duplicate",
	},
	RoleSalesExecutive: {"clients:read", "clients:create", "clients:update"},
	RoleOperations:     {"clients:read", "clients:create", "clients:update"},
	RoleTechnical:      {"clients:read"},
	RoleFinance:        {"clients:read", "clients:update"},
}

// Can reports whether the role grants the permission.
func (r Role) Can(perm string) bool {
	res, act, _ := strings.Cut(perm, ":")
	for _, p := range rolePermissions[r] {
		pr, pa, _ := strings.Cut(p, ":")
		if (pr == "*" || pr == res) && (pa == "*" || pa == act) {
			return true
		}
	}
	return false
}

// Expand lists concrete permissions the role holds out of the known set, so
// the frontend can show or hide actions.
func (r Role) Expand(known []string) []string {
	out := make([]string, 0, len(known))
	for _, k := range known {
		if r.Can(k) {
			out = append(out, k)
		}
	}
	return out
}
