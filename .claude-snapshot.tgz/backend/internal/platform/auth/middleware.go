package auth

import (
	"strings"

	"github.com/labstack/echo/v4"

	"dos-bpas/internal/platform/httpx"
)

// RequireAuth validates the bearer token and stores the Principal on the
// request context.
func (t *Tokens) RequireAuth() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			h := c.Request().Header.Get(echo.HeaderAuthorization)
			raw, ok := strings.CutPrefix(h, "Bearer ")
			if !ok || raw == "" {
				return httpx.ErrUnauthorized
			}
			p, err := t.Parse(raw)
			if err != nil {
				return httpx.ErrUnauthorized
			}
			req := c.Request()
			c.SetRequest(req.WithContext(WithPrincipal(req.Context(), p)))
			return next(c)
		}
	}
}

// Require rejects the request unless the user's role grants perm.
func Require(perm string) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			p, ok := FromContext(c.Request().Context())
			if !ok {
				return httpx.ErrUnauthorized
			}
			if !p.Can(perm) {
				return httpx.ErrForbidden
			}
			return next(c)
		}
	}
}
