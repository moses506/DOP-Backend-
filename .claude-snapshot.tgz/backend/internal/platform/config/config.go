// Package config loads runtime configuration from environment variables.
package config

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"time"
)

type Config struct {
	Env         string // development | production
	HTTPAddr    string
	DatabaseURL string
	JWTSecret   []byte
	AccessTTL   time.Duration
	CORSOrigins []string
	Location    *time.Location // business timezone, used for year-based numbering
}

func (c Config) IsProduction() bool { return c.Env == "production" }

func Load() (Config, error) {
	cfg := Config{
		Env:         get("APP_ENV", "development"),
		HTTPAddr:    get("HTTP_ADDR", ":8080"),
		DatabaseURL: os.Getenv("DATABASE_URL"),
		JWTSecret:   []byte(os.Getenv("JWT_SECRET")),
		CORSOrigins: split(get("CORS_ORIGINS", "http://localhost:5173")),
	}

	if cfg.DatabaseURL == "" {
		return cfg, errors.New("DATABASE_URL is required")
	}
	if len(cfg.JWTSecret) < 32 {
		return cfg, errors.New("JWT_SECRET must be at least 32 characters")
	}

	ttl, err := time.ParseDuration(get("ACCESS_TOKEN_TTL", "12h"))
	if err != nil {
		return cfg, fmt.Errorf("ACCESS_TOKEN_TTL: %w", err)
	}
	cfg.AccessTTL = ttl

	loc, err := time.LoadLocation(get("APP_TIMEZONE", "Africa/Lusaka"))
	if err != nil {
		return cfg, fmt.Errorf("APP_TIMEZONE: %w", err)
	}
	cfg.Location = loc

	return cfg, nil
}

func get(key, def string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return def
}

func split(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
