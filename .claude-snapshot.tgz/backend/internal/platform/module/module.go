// Package module defines the contract every business module implements.
//
// Rules (see README "Adding a module"):
//  1. A module owns its tables and migrations. Other modules refer to its
//     records by ID only and never query its tables directly.
//  2. Cross-module calls go through the other module's exported Service
//     interface, or through events.
//  3. Shared concerns (auth, audit, numbering, events, PDF, email) live in
//     internal/platform and are passed in through Deps.
package module

import (
	"io/fs"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/labstack/echo/v4"

	"dos-bpas/internal/platform/auth"
	"dos-bpas/internal/platform/events"
	"dos-bpas/internal/platform/numbering"
)

type Deps struct {
	DB      *pgxpool.Pool
	Tokens  *auth.Tokens
	Numbers *numbering.Service
	Events  *events.Bus
	Log     *slog.Logger
	Now     func() time.Time
}

type Router struct {
	Public *echo.Group // no authentication, e.g. login
	Authed *echo.Group // bearer token required
}

type Module interface {
	Name() string
	// Migrations returns the module's embedded SQL files, or nil.
	Migrations() fs.FS
	// Permissions lists the "resource:action" permissions this module checks.
	Permissions() []string
	Routes(r Router)
}
