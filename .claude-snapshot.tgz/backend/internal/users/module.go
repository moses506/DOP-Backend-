package users

import (
	"io/fs"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"

	"dos-bpas/internal/platform/auth"
	"dos-bpas/internal/platform/httpx"
	"dos-bpas/internal/platform/module"
)

const (
	PermRead   = "users:read"
	PermManage = "users:manage"
)

type Module struct {
	svc       *Service
	tokens    *auth.Tokens
	now       func() time.Time
	knownPerm func() []string
}

// New builds the module. knownPerms returns every permission declared by all
// registered modules, used to tell the frontend what the user may do.
func New(d module.Deps, knownPerms func() []string) *Module {
	return &Module{svc: NewService(d.DB, d.Now), tokens: d.Tokens, now: d.Now, knownPerm: knownPerms}
}

func (m *Module) Service() *Service     { return m.svc }
func (m *Module) Name() string          { return "users" }
func (m *Module) Migrations() fs.FS     { return nil } // users table is part of platform migrations
func (m *Module) Permissions() []string { return []string{PermRead, PermManage} }

func (m *Module) Routes(r module.Router) {
	r.Public.POST("/auth/login", m.login)
	r.Authed.GET("/auth/me", m.me)

	g := r.Authed.Group("/users")
	g.GET("", m.list, auth.Require(PermRead))
	g.POST("", m.create, auth.Require(PermManage))
	g.POST("/:id/activate", m.setActive(true), auth.Require(PermManage))
	g.POST("/:id/deactivate", m.setActive(false), auth.Require(PermManage))
}

type loginReq struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type session struct {
	Token       string    `json:"token"`
	ExpiresAt   time.Time `json:"expires_at"`
	User        User      `json:"user"`
	Permissions []string  `json:"permissions"`
}

func (m *Module) login(c echo.Context) error {
	var req loginReq
	if err := httpx.Bind(c, &req); err != nil {
		return err
	}
	u, err := m.svc.Authenticate(c.Request().Context(), req.Email, req.Password)
	if err != nil {
		return err
	}
	tok, exp, err := m.tokens.Issue(u.Principal(), m.now())
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, session{Token: tok, ExpiresAt: exp, User: u, Permissions: u.Role.Expand(m.knownPerm())})
}

func (m *Module) me(c echo.Context) error {
	p, _ := auth.FromContext(c.Request().Context())
	u, err := m.svc.Get(c.Request().Context(), p.UserID)
	if err != nil {
		return err
	}
	if !u.Active {
		return httpx.ErrUnauthorized
	}
	return c.JSON(http.StatusOK, map[string]any{"user": u, "permissions": u.Role.Expand(m.knownPerm())})
}

func (m *Module) list(c echo.Context) error {
	us, err := m.svc.List(c.Request().Context())
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, map[string]any{"items": us})
}

func (m *Module) create(c echo.Context) error {
	var in CreateInput
	if err := httpx.Bind(c, &in); err != nil {
		return err
	}
	u, err := m.svc.Create(c.Request().Context(), in)
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, u)
}

func (m *Module) setActive(active bool) echo.HandlerFunc {
	return func(c echo.Context) error {
		id, err := uuid.Parse(c.Param("id"))
		if err != nil {
			return httpx.ErrNotFound
		}
		u, err := m.svc.SetActive(c.Request().Context(), id, active)
		if err != nil {
			return err
		}
		return c.JSON(http.StatusOK, u)
	}
}
