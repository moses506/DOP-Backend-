// Package users manages staff accounts and sign-in.
package users

import (
	"context"
	"net/http"
	"net/mail"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"dos-bpas/internal/platform/audit"
	"dos-bpas/internal/platform/auth"
	"dos-bpas/internal/platform/db"
	"dos-bpas/internal/platform/httpx"
)

type User struct {
	ID          uuid.UUID  `json:"id"`
	Email       string     `json:"email"`
	FullName    string     `json:"full_name"`
	Position    string     `json:"position"`
	Department  string     `json:"department"`
	Role        auth.Role  `json:"role"`
	Active      bool       `json:"active"`
	LastLoginAt *time.Time `json:"last_login_at"`
	CreatedAt   time.Time  `json:"created_at"`
}

func (u User) Principal() auth.Principal {
	return auth.Principal{UserID: u.ID, Name: u.FullName, Position: u.Position, Role: u.Role}
}

type CreateInput struct {
	Email      string    `json:"email"`
	FullName   string    `json:"full_name"`
	Position   string    `json:"position"`
	Department string    `json:"department"`
	Role       auth.Role `json:"role"`
	Password   string    `json:"password"`
}

func (in *CreateInput) normalize() {
	in.Email = strings.ToLower(strings.TrimSpace(in.Email))
	in.FullName = strings.TrimSpace(in.FullName)
	in.Position = strings.TrimSpace(in.Position)
	in.Department = strings.TrimSpace(in.Department)
}

func (in CreateInput) validate() error {
	fe := httpx.FieldErrors{}
	if _, err := mail.ParseAddress(in.Email); err != nil {
		fe.Add("email", "Enter a valid email address.")
	}
	if in.FullName == "" {
		fe.Add("full_name", "Full name is required.")
	}
	if in.Position == "" {
		fe.Add("position", "Position is required.")
	}
	if in.Department == "" {
		fe.Add("department", "Department is required.")
	}
	if !in.Role.Valid() {
		fe.Add("role", "Choose a valid role.")
	}
	if len(in.Password) < 10 {
		fe.Add("password", "Password must be at least 10 characters.")
	}
	return fe.Err()
}

var ErrBadCredentials = httpx.NewError(http.StatusUnauthorized, "bad_credentials", "Email or password is incorrect.")

type Service struct {
	pool *pgxpool.Pool
	now  func() time.Time
}

func NewService(pool *pgxpool.Pool, now func() time.Time) *Service {
	return &Service{pool: pool, now: now}
}

const userCols = `id, email, full_name, position, department, role, active, last_login_at, created_at`

func scanUser(row pgx.Row) (User, error) {
	var u User
	err := row.Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Department, &u.Role,
		&u.Active, &u.LastLoginAt, &u.CreatedAt)
	return u, err
}

func (s *Service) Create(ctx context.Context, in CreateInput) (User, error) {
	in.normalize()
	if err := in.validate(); err != nil {
		return User{}, err
	}
	hash, err := auth.HashPassword(in.Password)
	if err != nil {
		return User{}, err
	}
	var u User
	err = db.WithTx(ctx, s.pool, func(tx pgx.Tx) error {
		u, err = scanUser(tx.QueryRow(ctx, `
			INSERT INTO users (email, full_name, position, department, role, password_hash)
			VALUES ($1,$2,$3,$4,$5,$6) RETURNING `+userCols,
			in.Email, in.FullName, in.Position, in.Department, in.Role, hash))
		if err != nil {
			if db.IsUniqueViolation(err) {
				return httpx.FieldErrors{"email": "A user with this email already exists."}.Err()
			}
			return err
		}
		return audit.Record(ctx, tx, audit.Entry{
			EntityType: "user", EntityID: u.ID, Action: "created",
			Summary: "User " + u.FullName + " created with role " + string(u.Role),
		})
	})
	return u, err
}

func (s *Service) Authenticate(ctx context.Context, email, password string) (User, error) {
	var hash string
	var u User
	err := s.pool.QueryRow(ctx, `SELECT `+userCols+`, password_hash FROM users WHERE lower(email) = lower($1)`,
		strings.TrimSpace(email)).Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Department, &u.Role,
		&u.Active, &u.LastLoginAt, &u.CreatedAt, &hash)
	if db.IsNoRows(err) {
		// Spend similar time as a real check so response timing does not reveal valid emails.
		auth.CheckPassword("pbkdf2_sha256$600000$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", password)
		return User{}, ErrBadCredentials
	}
	if err != nil {
		return User{}, err
	}
	if !u.Active || !auth.CheckPassword(hash, password) {
		return User{}, ErrBadCredentials
	}
	_, _ = s.pool.Exec(ctx, `UPDATE users SET last_login_at = $2 WHERE id = $1`, u.ID, s.now())
	return u, nil
}

func (s *Service) Get(ctx context.Context, id uuid.UUID) (User, error) {
	u, err := scanUser(s.pool.QueryRow(ctx, `SELECT `+userCols+` FROM users WHERE id = $1`, id))
	if db.IsNoRows(err) {
		return User{}, httpx.ErrNotFound
	}
	return u, err
}

func (s *Service) List(ctx context.Context) ([]User, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+userCols+` FROM users ORDER BY full_name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []User{}
	for rows.Next() {
		u, err := scanUser(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, u)
	}
	return out, rows.Err()
}

func (s *Service) SetActive(ctx context.Context, id uuid.UUID, active bool) (User, error) {
	var u User
	err := db.WithTx(ctx, s.pool, func(tx pgx.Tx) error {
		var err error
		u, err = scanUser(tx.QueryRow(ctx,
			`UPDATE users SET active = $2, updated_at = now() WHERE id = $1 RETURNING `+userCols, id, active))
		if db.IsNoRows(err) {
			return httpx.ErrNotFound
		}
		if err != nil {
			return err
		}
		action := "deactivated"
		if active {
			action = "activated"
		}
		return audit.Record(ctx, tx, audit.Entry{EntityType: "user", EntityID: id, Action: action,
			Summary: "User " + u.FullName + " " + action})
	})
	return u, err
}
