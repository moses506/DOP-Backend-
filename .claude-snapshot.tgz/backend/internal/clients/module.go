// Package clients is the client register: mandatory client registration,
// contacts, delivery sites, duplicate control and activity history
// (brief section 4.1). It is the reference module: copy its layout when
// adding deals, quotations and the rest.
//
//	module.go      – wiring: name, migrations, permissions, routes
//	handler.go     – HTTP only: parse request, call service, write response
//	service.go     – business rules, transactions, audit, events
//	repository.go  – all SQL for this module's tables
//	model.go       – types and validation
//	migrations/    – this module's tables
package clients

import (
	"io/fs"

	"dos-bpas/internal/clients/migrations"
	"dos-bpas/internal/platform/module"
)

const (
	PermRead              = "clients:read"
	PermCreate            = "clients:create"
	PermUpdate            = "clients:update"
	PermDeactivate        = "clients:deactivate"
	PermOverrideDuplicate = "clients:override_duplicate"
)

type Module struct {
	svc *Service
}

func New(d module.Deps) *Module {
	return &Module{svc: NewService(d.DB, d.Numbers, d.Events, d.Now)}
}

// API exposes the client service to other modules (by interface only).
func (m *Module) API() API { return m.svc }

func (m *Module) Name() string      { return "clients" }
func (m *Module) Migrations() fs.FS { return migrations.FS }
func (m *Module) Permissions() []string {
	return []string{PermRead, PermCreate, PermUpdate, PermDeactivate, PermOverrideDuplicate}
}

func (m *Module) Routes(r module.Router) {
	h := &handler{svc: m.svc}
	h.routes(r.Authed.Group("/clients"))
}
