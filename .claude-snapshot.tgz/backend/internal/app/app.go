// Package app wires the platform and all modules into one HTTP server.
// To add a module: construct it in buildModules and nothing else changes.
package app

import (
	"context"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"

	"dos-bpas/internal/clients"
	"dos-bpas/internal/platform/audit"
	"dos-bpas/internal/platform/auth"
	"dos-bpas/internal/platform/config"
	"dos-bpas/internal/platform/events"
	"dos-bpas/internal/platform/httpx"
	"dos-bpas/internal/platform/migrate"
	"dos-bpas/internal/platform/migrations"
	"dos-bpas/internal/platform/module"
	"dos-bpas/internal/platform/numbering"
	"dos-bpas/internal/users"
)

type App struct {
	Echo    *echo.Echo
	Modules []module.Module
	deps    module.Deps
}

func New(cfg config.Config, pool *pgxpool.Pool, log *slog.Logger) *App {
	deps := module.Deps{
		DB:      pool,
		Tokens:  auth.NewTokens(cfg.JWTSecret, cfg.AccessTTL),
		Numbers: numbering.New(cfg.Location),
		Events:  events.NewBus(log),
		Log:     log,
		Now:     time.Now,
	}
	a := &App{deps: deps}
	a.Modules = a.buildModules()
	a.Echo = a.buildHTTP(cfg, log)
	return a
}

// buildModules is the single registration point. Order matters only for
// migrations (a module's tables may reference platform tables).
func (a *App) buildModules() []module.Module {
	var mods []module.Module
	known := func() []string {
		var out []string
		for _, m := range mods {
			out = append(out, m.Permissions()...)
		}
		return append(out, "audit:read")
	}

	usersMod := users.New(a.deps, known)
	clientsMod := clients.New(a.deps)

	// Future modules receive the APIs they depend on, e.g.:
	//   dealsMod := deals.New(a.deps, clientsMod.API())
	mods = append(mods, usersMod, clientsMod)
	return mods
}

func (a *App) Migrate(ctx context.Context) error {
	sources := []migrate.Source{{Module: "platform", FS: migrations.FS}}
	for _, m := range a.Modules {
		if fsys := m.Migrations(); fsys != nil {
			sources = append(sources, migrate.Source{Module: m.Name(), FS: fsys})
		}
	}
	return migrate.Run(ctx, a.deps.DB, a.deps.Log, sources)
}

func (a *App) buildHTTP(cfg config.Config, log *slog.Logger) *echo.Echo {
	e := echo.New()
	e.HideBanner, e.HidePort = true, true
	e.HTTPErrorHandler = httpx.ErrorHandler(log)

	e.Use(middleware.RequestID())
	e.Use(middleware.Recover())
	e.Use(middleware.BodyLimit("10M"))
	e.Use(middleware.SecureWithConfig(middleware.SecureConfig{
		XSSProtection: "0", ContentTypeNosniff: "nosniff", XFrameOptions: "DENY",
		HSTSMaxAge: hsts(cfg), ReferrerPolicy: "same-origin",
	}))
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: cfg.CORSOrigins,
		AllowHeaders: []string{echo.HeaderAuthorization, echo.HeaderContentType},
		AllowMethods: []string{http.MethodGet, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete},
	}))
	e.Use(requestLogger(log))
	e.Use(func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			r := c.Request()
			c.SetRequest(r.WithContext(audit.WithRequestID(r.Context(), httpx.RequestID(c))))
			return next(c)
		}
	})

	e.GET("/healthz", func(c echo.Context) error {
		if err := a.deps.DB.Ping(c.Request().Context()); err != nil {
			return c.JSON(http.StatusServiceUnavailable, map[string]string{"status": "db_unavailable"})
		}
		return c.JSON(http.StatusOK, map[string]string{"status": "ok"})
	})

	api := e.Group("/api")
	r := module.Router{Public: api, Authed: api.Group("", a.deps.Tokens.RequireAuth())}
	for _, m := range a.Modules {
		m.Routes(r)
	}
	api.Any("/*", func(echo.Context) error { return httpx.ErrNotFound })

	// Optionally serve the built frontend from the same server (WEB_DIR=../frontend/dist).
	if dir := os.Getenv("WEB_DIR"); dir != "" {
		e.GET("/*", spa(dir))
	}
	return e
}

func hsts(cfg config.Config) int {
	if cfg.IsProduction() {
		return 31536000
	}
	return 0
}

func requestLogger(log *slog.Logger) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			start := time.Now()
			err := next(c)
			if err != nil {
				c.Error(err)
			}
			if strings.HasPrefix(c.Path(), "/api") {
				log.Info("http",
					"method", c.Request().Method, "path", c.Path(), "status", c.Response().Status,
					"ms", time.Since(start).Milliseconds(), "request_id", httpx.RequestID(c))
			}
			return nil
		}
	}
}

// spa serves static files and falls back to index.html for client routes.
func spa(dir string) echo.HandlerFunc {
	return func(c echo.Context) error {
		p := filepath.Join(dir, filepath.Clean("/"+c.Param("*")))
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			if strings.HasSuffix(p, "sw.js") || strings.HasSuffix(p, "index.html") {
				c.Response().Header().Set("Cache-Control", "no-cache")
			}
			return c.File(p)
		}
		c.Response().Header().Set("Cache-Control", "no-cache")
		return c.File(filepath.Join(dir, "index.html"))
	}
}
