// Command admin runs maintenance tasks, e.g. creating the first administrator:
//
//	go run ./cmd/admin create-user -email admin@dos.co.zm -name "System Admin" \
//	    -position "Systems Developer" -department "IT" -role admin
//
// The password is read from the ADMIN_PASSWORD environment variable, or
// prompted for, so it never appears in shell history.
package main

import (
	"bufio"
	"context"
	"flag"
	"fmt"
	"log/slog"
	"os"
	"strings"

	_ "time/tzdata"

	"dos-bpas/internal/app"
	"dos-bpas/internal/platform/auth"
	"dos-bpas/internal/platform/config"
	"dos-bpas/internal/platform/db"
	"dos-bpas/internal/users"
)

func main() {
	if len(os.Args) < 2 || os.Args[1] != "create-user" {
		fmt.Fprintln(os.Stderr, "usage: admin create-user -email E -name N -position P -department D -role R")
		os.Exit(2)
	}
	fs := flag.NewFlagSet("create-user", flag.ExitOnError)
	email := fs.String("email", "", "email address")
	name := fs.String("name", "", "full name")
	position := fs.String("position", "", "job title")
	dept := fs.String("department", "", "department")
	role := fs.String("role", "admin", "role: ceo|sales_manager|sales_executive|operations|technical|finance|admin")
	_ = fs.Parse(os.Args[2:])

	if err := createUser(*email, *name, *position, *dept, auth.Role(*role)); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

func createUser(email, name, position, dept string, role auth.Role) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	ctx := context.Background()
	pool, err := db.Connect(ctx, cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer pool.Close()

	log := slog.New(slog.NewTextHandler(os.Stderr, nil))
	a := app.New(cfg, pool, log)
	if err := a.Migrate(ctx); err != nil {
		return err
	}

	pw := os.Getenv("ADMIN_PASSWORD")
	if pw == "" {
		fmt.Print("Password (min 10 chars): ")
		line, _ := bufio.NewReader(os.Stdin).ReadString('\n')
		pw = strings.TrimSpace(line)
	}
	u, err := users.NewService(pool, nil).Create(ctx, users.CreateInput{
		Email: email, FullName: name, Position: position, Department: dept, Role: role, Password: pw,
	})
	if err != nil {
		return err
	}
	fmt.Printf("created %s (%s) id=%s\n", u.Email, u.Role, u.ID)
	return nil
}
